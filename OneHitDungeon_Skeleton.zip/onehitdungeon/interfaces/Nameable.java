package onehitdungeon.interfaces;

public interface Nameable {
    String getName();
}
