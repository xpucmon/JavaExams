package exodiaspring.web.controllers;

import exodiaspring.domain.entities.Document;
import exodiaspring.domain.models.binding.DocumentScheduleBindingModel;
import exodiaspring.domain.models.service.DocumentServiceModel;
import exodiaspring.domain.models.view.DocumentViewModel;
import exodiaspring.service.DocumentService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpSession;

@Controller
public class DocumentController {

    private final DocumentService documentService;
    private final ModelMapper modelMapper;

    @Autowired
    public DocumentController(DocumentService documentService, ModelMapper modelMapper) {
        this.documentService = documentService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/schedule")
    public ModelAndView schedule(ModelAndView modelAndView, HttpSession httpSession){
        if (httpSession.getAttribute("username") != null){
            modelAndView.setViewName("schedule");
        } else {
            modelAndView.setViewName("redirect:/login");
        }

        return modelAndView;
    }

    @PostMapping("/schedule")
    public ModelAndView scheduleConfirm(@ModelAttribute DocumentScheduleBindingModel bindingModel,
                                        ModelAndView modelAndView){

        DocumentServiceModel documentServiceModel = this.modelMapper
                .map(bindingModel, DocumentServiceModel.class);

        if (documentServiceModel == null){
            throw new IllegalArgumentException("Document schedule is unsuccessful!");
        }

        documentServiceModel = this.documentService.scheduleDocument(documentServiceModel);

        modelAndView.setViewName("redirect:/details/" + documentServiceModel.getId());

        return modelAndView;
    }

    @GetMapping("/details/{id}")
    public ModelAndView details(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession httpSession){
        if (httpSession.getAttribute("username") != null){
            DocumentServiceModel documentServiceModel = this.documentService.findDocumentById(id);

            if (documentServiceModel == null){
                throw new IllegalArgumentException("Document could not be found!");
            }

            modelAndView.setViewName("details");
            modelAndView.addObject("model", this.modelMapper.map(documentServiceModel, DocumentViewModel.class));
        } else {
            modelAndView.setViewName("redirect:/login");
        }

        return modelAndView;
    }

    @GetMapping("/print/{id}")
    public ModelAndView print(@PathVariable(name = "id") String id, ModelAndView modelAndView, HttpSession httpSession){
        if (httpSession.getAttribute("username") != null){
            DocumentServiceModel documentServiceModel = this.documentService.findDocumentById(id);

            if (documentServiceModel == null){
                throw new IllegalArgumentException("Document could not be found!");
            }

            modelAndView.setViewName("print");
            modelAndView.addObject("model", this.modelMapper.map(documentServiceModel, DocumentViewModel.class));
        } else {
            modelAndView.setViewName("redirect:/login");
        }

        return modelAndView;
    }

    @PostMapping("/print/{id}")
    public ModelAndView printConfirm(@PathVariable("id") String id, ModelAndView modelAndView){

        if (!this.documentService.printDocument(id)){
            throw new IllegalArgumentException("Document print is unsuccessful!");
        }

        modelAndView.setViewName("redirect:/home");
        return modelAndView;
    }
}
