package exodiaspring.web.controllers;

import exodiaspring.domain.models.binding.UserLoginBindingModel;
import exodiaspring.domain.models.binding.UserRegisterBindingModel;
import exodiaspring.domain.models.service.UserServiceModel;
import exodiaspring.service.UserService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;

import javax.servlet.http.HttpSession;
import javax.validation.Valid;

@Controller
public class UserController implements WebMvcConfigurer {

    private final UserService userService;
    private final ModelMapper modelMapper;

    @Autowired
    public UserController(UserService userService, ModelMapper modelMapper) {
        this.userService = userService;
        this.modelMapper = modelMapper;
    }

    @GetMapping("/register")
    public ModelAndView register(ModelAndView modelAndView, HttpSession httpSession){
        if (httpSession.getAttribute("username") != null){
            modelAndView.setViewName("redirect:/home");
        } else {
            modelAndView.setViewName("register");
        }

        return modelAndView;
    }

    @PostMapping("/register")
    public ModelAndView registerConfirm(@ModelAttribute UserRegisterBindingModel bindingModel,
                                        ModelAndView modelAndView){

        if (!bindingModel.getPassword().equals(bindingModel.getConfirmPassword())){
            throw new IllegalArgumentException("Passwords do not match!");
        }

        if (!this.userService.userRegister(this.modelMapper.map(bindingModel, UserServiceModel.class))){
            throw new IllegalArgumentException("User could not be registered!");
        }

        modelAndView.setViewName("redirect:/login");

        return modelAndView;
    }

    @GetMapping("/login")
    public ModelAndView login(ModelAndView modelAndView, HttpSession httpSession){
        if (httpSession.getAttribute("username") != null){
            modelAndView.setViewName("redirect:/home");
        } else {
            modelAndView.setViewName("login");
        }

        return modelAndView;
    }

    @PostMapping("/login")
    public ModelAndView loginConfirm(@ModelAttribute @Valid UserLoginBindingModel bindingModel,
                                        ModelAndView modelAndView, HttpSession httpSession, BindingResult bindingResult){

        UserServiceModel userServiceModel = this.userService.userLogin(this.modelMapper
                .map(bindingModel, UserServiceModel.class));

        if (userServiceModel == null){
            throw new IllegalArgumentException("User could not be logged in!");
        }

        httpSession.setAttribute("userId", userServiceModel.getId());
        httpSession.setAttribute("username", userServiceModel.getUsername());

        if (bindingResult.hasErrors()){
            ModelAndView mav = new ModelAndView("form");
            mav.addObject(bindingResult);
            return mav;
        }

        modelAndView.setViewName("redirect:/home");

        return modelAndView;
    }

    @GetMapping("/logout")
    public ModelAndView logout(ModelAndView modelAndView, HttpSession httpSession){
        if (httpSession.getAttribute("username") == null){
            modelAndView.setViewName("redirect:/login");
        } else {
            httpSession.invalidate();
            modelAndView.setViewName("redirect:/");
        }

        return modelAndView;
    }
}
