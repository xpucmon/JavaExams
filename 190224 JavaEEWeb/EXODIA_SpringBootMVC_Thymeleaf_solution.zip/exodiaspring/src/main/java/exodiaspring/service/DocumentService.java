package exodiaspring.service;

import exodiaspring.domain.models.service.DocumentServiceModel;

import java.util.List;

public interface DocumentService {

    DocumentServiceModel scheduleDocument(DocumentServiceModel documentServiceModel);

    DocumentServiceModel findDocumentById(String id);

    boolean printDocument(String id);

    List<DocumentServiceModel> findAllDocuments();
}
