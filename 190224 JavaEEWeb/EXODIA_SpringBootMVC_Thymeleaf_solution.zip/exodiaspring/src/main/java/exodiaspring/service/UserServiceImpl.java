package exodiaspring.service;

import exodiaspring.domain.entities.User;
import exodiaspring.domain.models.service.UserServiceModel;
import exodiaspring.repository.UserRepository;
import org.apache.commons.codec.digest.DigestUtils;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserServiceImpl implements UserService {
    private final UserRepository userRepository;
    private final ModelMapper modelMapper;

    @Autowired
    public UserServiceImpl(UserRepository userRepository, ModelMapper modelMapper) {
        this.userRepository = userRepository;
        this.modelMapper = modelMapper;
    }

    @Override
    public boolean userRegister(UserServiceModel userServiceModel) {
        User user = this.modelMapper.map(userServiceModel, User.class);

        try {
            user.setPassword(DigestUtils.sha256Hex(userServiceModel.getPassword()) );
            this.userRepository.saveAndFlush(user);

            return true;
        } catch (Exception ex){
            ex.printStackTrace();

            return false;
        }
    }

    @Override
    public UserServiceModel userLogin(UserServiceModel userServiceModel) {
        User user = this.userRepository.findByUsername(userServiceModel.getUsername()).orElse(null);

        if (user == null || !DigestUtils.sha256Hex(userServiceModel.getPassword()).equals(user.getPassword()) ){
            return null;
        }

        return this.modelMapper.map(user, UserServiceModel.class);
    }
}
