package constants;

public class HeroTypes {
    public static final String DUNMER = "DUNMER";
    public static final String REDGUARD = "REDGUARD";
    public static final String KHAJIIT = "KHAJIIT";
    public static final String ORSIMER = "ORSIMER";
    public static final String NORD = "NORD";
    public static final String BRETON = "BRETON";
}
