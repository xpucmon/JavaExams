package io;

import java.io.IOException;

public interface Reader {
    String read() throws IOException;
}
