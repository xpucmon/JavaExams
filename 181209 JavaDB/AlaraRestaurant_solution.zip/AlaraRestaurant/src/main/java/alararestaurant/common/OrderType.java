package alararestaurant.common;

public enum OrderType {
    ForHere,
    ToGo
}
