package alararestaurant.common;

public class Constants {

    public final static String INVALID_DATA_FORMAT = "Invalid data format.";
    public final static String SUCCESSFULLY_IMPORTED_JSON = "Record %s successfully imported.";
    public final static String SUCCESSFULLY_IMPORTED_XML = "Order for %s on %s added";

}
