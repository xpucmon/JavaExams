package onehitdungeon.core;

import onehitdungeon.entities.heroes.MageHero;
import onehitdungeon.entities.heroes.PaladinHero;
import onehitdungeon.interfaces.DungeonManager;
import onehitdungeon.interfaces.Hero;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public class DungeonManagerImpl implements DungeonManager {
    private Map<String, Hero> heroes;
    private Hero selectedHero;

    public DungeonManagerImpl(Map<String, Hero> heroes) {
        this.heroes = new LinkedHashMap<>();
    }

    @Override
    public String hero(List<String> arguments) {
        String type = arguments.get(0);
        String name = arguments.get(1);

        Hero hero = null;
        switch (type) {
            case "Paladin":
                hero = new PaladinHero(name);
                break;
            case "Mage":
                hero = new MageHero(name);
                break;
        }
        this.heroes.put(name, hero);
        if (this.selectedHero == null){
            this.selectedHero = hero;
        }
        return String.format("Successfully added %s - %s.", type, name);
    }

    @Override
    public String select(List<String> arguments) {
        return null;
    }

    @Override
    public String status(List<String> arguments) {
        return null;
    }

    @Override
    public String fight(List<String> arguments) {
        return null;
    }

    @Override
    public String advance(List<String> arguments) {
        return null;
    }

    @Override
    public String train(List<String> arguments) {
        return null;
    }

    @Override
    public String quit(List<String> arguments) {
        return null;
    }
}
