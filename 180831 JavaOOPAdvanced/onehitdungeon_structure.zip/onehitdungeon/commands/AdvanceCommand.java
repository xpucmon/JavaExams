package onehitdungeon.commands;

public class AdvanceCommand {
}
