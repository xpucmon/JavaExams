package onehitdungeon.commands;

public class SelectCommand {
}
