package onehitdungeon.commands;

public class TrainCommand {
}
