package onehitdungeon.commands;

public class QuitCommand {
}
