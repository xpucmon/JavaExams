package onehitdungeon.commands;

public class HeroCommand {
}
