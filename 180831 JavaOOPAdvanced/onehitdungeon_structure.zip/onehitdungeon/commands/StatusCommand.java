package onehitdungeon.commands;

public class StatusCommand {
}
