package onehitdungeon.entities.heroes;

import onehitdungeon.entities.items.ArmorItemImpl;
import onehitdungeon.entities.items.OffhandItemImpl;
import onehitdungeon.entities.items.WeaponItemImpl;

public class PaladinHero extends BaseHero {
    public PaladinHero(String name) {
        super(name, new WeaponItemImpl(20, 10.0),
                new OffhandItemImpl(10, 10.0),
                new ArmorItemImpl(25, 20.0));
    }
}
