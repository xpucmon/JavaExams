package onehitdungeon.entities.heroes;

import onehitdungeon.entities.items.ArmorItemImpl;
import onehitdungeon.entities.items.OffhandItemImpl;
import onehitdungeon.entities.items.WeaponItemImpl;

public class MageHero extends BaseHero {
    public MageHero(String name) {
        super(name, new WeaponItemImpl(45, 15.0),
                new OffhandItemImpl(25, 20.0),
                new ArmorItemImpl(10, 25.0));
    }
}
