package onehitdungeon.entities.heroes;

import onehitdungeon.interfaces.ArmorItem;
import onehitdungeon.interfaces.Hero;
import onehitdungeon.interfaces.OffhandItem;
import onehitdungeon.interfaces.WeaponItem;

public abstract class BaseHero implements Hero {
    private String name;
    private WeaponItem weapon;
    private OffhandItem offhand;
    private ArmorItem armor;
    private double gold;

    public BaseHero(String name, WeaponItem weapon, OffhandItem offhand, ArmorItem armor) {
        this.name = name;
        this.weapon = weapon;
        this.offhand = offhand;
        this.armor = armor;
    }

    @Override
    public String getHeroClass() {
        return this.getClass().getSimpleName();
    }

    @Override
    public Double getGold() {
        return this.gold;
    }

    @Override
    public void earnGold(Double gold) {
        this.gold += gold;
    }

    @Override
    public void payGold(Double gold) {
        if (gold >= this.gold){
            this.gold -= gold;
        } else {
            this.gold = 0.0; //TODO check???
        }
    }

    @Override
    public WeaponItem getWeapon() {
        return this.weapon;
    }

    @Override
    public OffhandItem getOffhand() {
        return this.offhand;
    }

    @Override
    public ArmorItem getArmor() {
        return this.armor;
    }

    @Override
    public Integer getTotalBattlePower() {
        return null; //TODO
    }

    @Override
    public Double getTotalPriceForUpgrade() {
        return null; //TODO
    }

    @Override
    public String getName() {
        return this.name;
    }

    @Override
    public String toString() {
        return super.toString(); //TODO
    }
}
