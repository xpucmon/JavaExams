package onehitdungeon.interfaces;

public interface OffhandItem extends Item {
}
